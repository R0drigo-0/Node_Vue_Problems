<script>
import p1 from './components/p1.vue';
import p2 from './components/p2.vue';
import p3 from './components/p3.vue';
import p4 from './components/p4.vue';
import p5 from './components/p5.vue';
import p6 from './components/p6.vue';
import p7 from './components/p7.vue';
import p8 from './components/p8.vue';
import p9 from './components/p9.vue';
import p10 from './components/p10.vue';
import p11 from './components/p11.vue';
import p12own from './components/p12own.vue';
import p12 from './components/p12own.vue';
import p13 from './components/p13.vue';
import p14 from './components/p14.vue';
import p15 from './components/p15.vue';
import p16 from './components/p16.vue';
import p17 from './components/p17.vue';
import p18 from './components/p18.vue';
import p19 from './components/p19.vue';
import p20 from './components/p20.vue';
import p21 from './components/p21.vue';
import p22 from './components/p22.vue';
export default {
  name: 'App',
  components:  {
    p1,
    p2,
    p3,
    p4,
    p5,
    p6,
    p7,
    p8,
    p9,
    p10,
    p11,
    p12own,
    p12,
    p13,
    p14,
    p15,
    p16,
    p17,
    p18,
    p19,
    p20,
    p21,
    p22
  },
};

</script>

<template>
  <div id="app">
    <p1 />
    <p2 />
    <p3 />
    <p4 />
    <p5 />
    <p6 />
    <p7 />
    <p8 />
    <p9 />
    <p10 />
    <p11 />
    <p12own />
    <p12 />
    <p13 />
    <p14 />
    <p15 />
    <p16 />
    <p17 />
    <p18 />
    <p19 />
    <p20 />
    <p21 />
    <p22 />
  </div>
</template>

<style scoped>
*{
  box-sizing: border-box;
  gap: 0;
  margin: 0;
  padding: 0;
  border: 0;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
}

#app > *{
  margin: 10px;
}
</style>
